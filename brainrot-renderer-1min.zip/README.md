# Brainrot FFmpeg Renderer

FFmpeg renderer for the n8n Brainrot workflow.

For ~1 minute: use 6 scenes x 10 seconds, or set explicit `duration` per scene.
The renderer accepts `video_url`, `audio_url`, `subtitle` and `duration`.
Audio can be uploaded through `/upload-audio`; use its returned `public_url` in `/render`.
